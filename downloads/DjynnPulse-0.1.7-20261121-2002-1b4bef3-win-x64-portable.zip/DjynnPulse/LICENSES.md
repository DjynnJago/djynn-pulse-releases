# Djynn Pulse — Licences and Third-Party Notices

**Djynn Pulse** © 2026 Digital Djynn (Djynn Ex Machina). All rights reserved.
Proprietary software. Distribution terms for end users are set by Digital Djynn.

> Note for the publisher: no end-user licence agreement text has been written for 0.1.0-alpha.
> Add your EULA here before public release; the installer displays this file.

## Components shipped with Djynn Pulse

| Component | Use | Licence |
|---|---|---|
| .NET 8 runtime and Windows Desktop runtime (WPF) | Bundled in the self-contained installer and portable package | MIT — https://github.com/dotnet/runtime/blob/main/LICENSE.TXT, https://github.com/dotnet/wpf/blob/main/LICENSE.TXT |

| System.Management 10.0.2 (Microsoft) | WMI access (LibreHardwareMonitor sensors) | MIT — https://github.com/dotnet/runtime/blob/main/LICENSE.TXT |
| LibreHardwareMonitorLib 0.9.6 | CPU temperature and power through PawnIO (only the CPU part is enabled) | MPL-2.0 — https://github.com/LibreHardwareMonitor/LibreHardwareMonitor (unmodified; source available there) |
| DiskInfoToolkit 1.1.2, RAMSPDToolkit-NDD 1.4.2 (dependencies of LibreHardwareMonitorLib; not used) | — | MPL-2.0 — https://github.com/Blacktempel |
| HidSharp 2.6.4 (dependency of LibreHardwareMonitorLib; not used) | — | Apache-2.0 — https://www.zer7.com/software/hidsharp |
| System.IO.Ports, System.Threading.AccessControl 10.0, Mono.Posix.NETStandard 1.0 (dependencies) | — | MIT |
| PawnIO setup (`PawnIO_setup.exe`, by namazso), shipped unmodified | Installs the PawnIO driver for CPU temperature, only if the user agrees | PawnIO is open source (GPL-2.0 driver, LGPL-2.1 modules) — https://pawnio.eu, https://github.com/namazso/PawnIO |

MPL-2.0 applies per file: Djynn Pulse ships these libraries unmodified and does not include
their source in its own code.

Djynn Pulse otherwise uses only Windows APIs (kernel32, ntdll, pdh, user32, advapi32, powrprof,
psapi) and the .NET runtime.

## Graphics-driver libraries used at run time (not shipped)

Djynn Pulse loads these from System32 if the graphics driver installed them. It does not
redistribute them and calls only read-only telemetry functions.

| Library | Installed by | Use |
|---|---|---|
| `atiadlxx.dll` (AMD Display Library, ADL) | AMD Software: Adrenalin Edition | GPU temperature, hotspot, clocks, power, fan (Overdrive 8: Vega, RX 5000 and newer) |
| `nvml.dll` (NVIDIA Management Library) | NVIDIA graphics driver | GPU temperature, clocks, power, fan |

## Hardware monitors read while running (not shipped)

Djynn Pulse reads CPU temperature itself when the PawnIO driver is installed. Without it, it
reads these tools when the user runs them, using only the data they publish.

| Tool | How it is read | Licence |
|---|---|---|
| HWiNFO | Shared memory `Global\HWiNFO_SENS_SM2` (enable *Shared Memory Support*) | Freeware; shared memory is time-limited in the free edition |
| LibreHardwareMonitor | WMI namespace `root\LibreHardwareMonitor` | MPL-2.0 — https://github.com/LibreHardwareMonitor/LibreHardwareMonitor |

## Intel PresentMon (shipped)

| Component | Use | Licence |
|---|---|---|
| Intel PresentMon 2.6.0 console (`PresentMon\PresentMon-2.6.0-x64.exe`), unmodified, signed by Intel | FPS and frame-time capture | MIT, © 2017-2024 Intel Corporation. The licence text ships as `PresentMon\LICENSE.txt`. Source: https://github.com/GameTechDev/PresentMon |

## Development-only dependencies (tests; not distributed)

| Package | Licence |
|---|---|
| xunit 2.5.3, xunit.runner.visualstudio 2.5.3 | Apache-2.0 |
| Microsoft.NET.Test.Sdk 17.8.0 | MIT |

## Tools used to build the installer

| Tool | Licence |
|---|---|
| Inno Setup 6 | Inno Setup licence (free for commercial use) — https://jrsoftware.org/files/is/license.txt |
