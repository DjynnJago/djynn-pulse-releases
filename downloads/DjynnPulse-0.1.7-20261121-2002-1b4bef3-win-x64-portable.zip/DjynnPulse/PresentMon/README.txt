Intel PresentMon 2.6.0 (console), included unmodified for FPS and frame-time capture.
Licence: MIT (LICENSE.txt in this folder). Source: https://github.com/GameTechDev/PresentMon
To use a different PresentMon version, replace the .exe here or choose it in Monitoring Configuration.
