# Djynn Pulse

**Digital Djynn · Djynn Ex Machina · Unleashing the Djynn**
Version 0.1.0-alpha · Windows 10/11 x64 · https://www.digitaldjynn.com

Djynn Pulse is a lightweight Windows gaming performance diagnostic tool. It finds likely causes of
stutter, frame-time instability, abnormal disk activity, driver problems and resource bottlenecks,
explains them in plain language, and offers safe, reversible fixes, while keeping its own
footprint small.

## What it does

- **Simple Mode** (default): Start/Stop monitoring, current game, current, average and 1% low FPS,
  frame-time stability, CPU, GPU, RAM, VRAM and disk activity, health summary, detected problems,
  recommended fixes, *Apply Selected Fixes* and *Send Diagnostic*.
- **Advanced Mode**: collapsible panels for frame-time graph and distribution, per-process CPU,
  GPU engines, memory and paging, physical disk throughput/latency/queue, per-process logical I/O,
  drivers and services, event correlation, the AMD/ATI Disk-Write Inspector, the Existing
  Workaround Inspector, Smart Fix Engine details with rollback, before-and-after benchmarking,
  event history, application errors, **Djynn Resource Usage**, and monitoring configuration.
- **Monitoring profiles**: Ultra-Light (default), Balanced, Deep Analysis.
- **Privacy-first diagnostics**: preview and choose what goes in the ZIP. Usernames, profile paths,
  emails, IP and MAC addresses and credentials are redacted. Nothing is sent automatically.

## Frame-time capture (PresentMon)

FPS and frame times come from **Intel PresentMon 2.6.0** (MIT licence), which is included in the
`PresentMon` folder next to `DjynnPulse.exe`. To use another version, replace it there or choose
it in *Advanced → Monitoring Configuration*. Capturing frames needs
administrator rights or membership of the Windows **Performance Log Users** group. Without
PresentMon, frame-time fields show *Unavailable* and all other monitoring still works.
See [docs/PRESENTMON.md](docs/PRESENTMON.md).

## Safety model

- The main app runs **without** administrator rights.
- Every fix shows the exact change and needs your explicit approval. Original values are recorded
  in a journal (`%LOCALAPPDATA%\DigitalDjynn\DjynnPulse\fix-journal.json`) before anything changes.
  The result is verified, and rollback is available.
- Changes that need administrator rights go through `DjynnPulse.ElevatedHelper.exe`. It performs
  exactly one operation from a fixed allow-list per launch (set or clear HAGS; stop or start the
  *AMD External Events Utility* service) and nothing else.
- Djynn Pulse never disables security features, deletes caches, changes drivers, or runs downloaded commands.

## Documentation

- [BUILD_INSTRUCTIONS.md](BUILD_INSTRUCTIONS.md): build, test, package
- [LICENSES.md](LICENSES.md): licences and third-party notices
- [RELEASE_NOTES.md](RELEASE_NOTES.md): what is in this version, known limitations
- [docs/METRICS.md](docs/METRICS.md): how every number is calculated
- [docs/TESTING.md](docs/TESTING.md): what was actually tested, and measured overhead
- [docs/PRESENTMON.md](docs/PRESENTMON.md): frame-capture setup
- [docs/WEBSITE.md](docs/WEBSITE.md): website listing copy and release rules

Support: digitaldjynn@outlook.com
