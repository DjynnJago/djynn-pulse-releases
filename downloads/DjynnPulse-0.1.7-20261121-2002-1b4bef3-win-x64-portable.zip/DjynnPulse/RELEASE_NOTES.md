# Djynn Pulse 0.1.0-alpha — Release Notes

First alpha of Djynn Pulse by Digital Djynn. **Alpha software: test before relying on it.**

## Unreleased changes since the first 0.1.0-alpha build

- **FPS drops are reported as one event, not many spikes.** A run of at least 5 spike frames in a
  row is now one *FPS drop* (configurable), with its length and frame rate. Previously one slow
  stretch could be counted as dozens of spikes. Reports show the drop count and total time.
- **Bottleneck findings look only at the slow moments.** "GPU-limited" now needs the GPU to be
  pinned *during* FPS drops (or across a low-FPS session) with no CPU core saturated. A GPU at
  100 % across a session is no longer reported on its own: that is normal for an uncapped game.
  New outcomes: *possibly CPU-limited during slow stretches* (GPU has spare capacity, one core
  pinned) and *slow stretches not explained by CPU or GPU load*. Without per-core data
  (Ultra-Light) a GPU verdict is marked low confidence.
- **Redaction no longer blanks brand names.** When the Windows user name is "Djynn" (or another
  brand word), "Djynn Pulse", "Digital Djynn", "Djynn Ex Machina" and the website are kept.
  The computer name is now replaced before the user name, so "DJYNN-PC" becomes `<computer>`
  rather than `<user>-PC`.
- Disk response time in reports shows one decimal place (fast NVMe drives showed "0 ms").
- The portable package includes `measure-overhead.ps1`.
- **Intel PresentMon 2.6.0 is now included** (`PresentMon` folder, MIT licence text alongside), so
  FPS and frame times work without a separate download.
- **Hardware sensors.** GPU temperature, hotspot and memory temperature, core and memory clock,
  power and fan, from the graphics driver's own library: AMD ADL (`atiadlxx.dll`) or NVIDIA NVML
  (`nvml.dll`). CPU temperature and package power, plus anything the driver library lacks, from
  HWiNFO (Shared Memory Support) or LibreHardwareMonitor when either is running. No driver is
  installed and no admin rights are needed. Readings appear under the CPU and GPU tiles, in the
  Advanced CPU and GPU panels, in `summary.txt` and as new `performance.csv` columns.
- **CPU temperature inside Djynn Pulse**: via LibreHardwareMonitorLib and the signed, open-source
  PawnIO driver, offered by the installer and by an *Install CPU temperature driver* button
  (Advanced › Settings › Monitoring Configuration). Only CPU sensors are enabled. Read only while
  Djynn Pulse runs as administrator. Verified on a Ryzen 9 5900X.
- **The CPU tile says why the temperature is missing**: monitoring not started, needs
  administrator, or needs the CPU driver. *Restart as administrator* now appears whenever PawnIO is
  installed and Djynn Pulse is not elevated, and after installing PawnIO from the app you are
  offered a restart. A restart during monitoring asks first. Djynn Pulse still starts without
  administrator rights by default.
- **One interface instead of Simple and Advanced modes** (developer's decision, replacing the spec's
  two modes): the Dashboard holds everything Simple mode showed; the sidebar pages hold the detail.
  Detail pages refresh only while shown, so overhead on the Dashboard matches the old Simple mode.
- **Djynn Scrye look** (developer's decision; replaces the spec's grey-and-purple palette): neon plum
  colours, cards with a magenta glow along the top, a full-height sidebar with the logo in a gradient
  tile, a gradient page title with a glowing line and status strip, gradient buttons, and magenta/teal
  charts. Djynn Pulse and Djynn Scrye now look like one family.
- **How-to guide**: a Help page in the app (sidebar and a *How to use* button in the header) and
  "How to use Djynn Pulse.html" next to DjynnPulse.exe, also in the Start menu.
- **One-click install**: the installer ticks everything by default (PawnIO for CPU temperature, start
  as administrator so FPS capture and CPU temperature just work, desktop icon) and offers to open the
  guide and launch the app. *Start as administrator* is a developer decision that relaxes the spec's
  "non-elevated by default"; users can untick it. `Build Djynn Pulse installer.cmd` builds it all.
- **NVIDIA in the disk-write inspector.** Watches NVDisplay.Container.exe, the NVIDIA app, overlay
  and capture helpers alongside AMD's processes. Knows the 2026 bug where GeForce drivers 621.14 and
  621.24 keep rewriting `C:\ProgramData\NVIDIA Corporation\nvtopps\nct\nvlog.nvlgstg`: reads the
  driver version, shows the log file's size and last write time, and recommends hotfix 621.35 or newer
  (or rolling back to 621.01). AMD's acknowledged atieclxx.exe idle-write issue (PA-365) is described
  too. Nothing is stopped, changed or deleted automatically.
- **Disk Writes page** in the sidebar, under Performance: the inspector, disk activity chart and
  process I/O table in one place.
- **Redesigned interface**: sidebar navigation, card layout, Performance page with captures and
  Capture / Analysis / Comparison / Sensors tabs, and a CPU vs GPU page.
- New findings: *CPU running very hot*, *GPU running very hot*, and *GPU clock fell during FPS
  drops* (a sign of thermal or power limits), with a *Check cooling and fan settings* recommendation.

## Included

- Dashboard plus detail pages (originally Simple and Advanced modes), dark interface, DPI-aware, keyboard accessible.
- Ultra-Light / Balanced / Deep Analysis monitoring profiles with bounded in-memory history.
  No diagnostic data is written to disk during monitoring.
- CPU (total, per-core, effective clock), RAM, paging, physical disk throughput/latency/queue/IOPS,
  per-process CPU and logical I/O, GPU utilisation by engine and VRAM (vendor-neutral WDDM counters).
- Automatic game detection plus manual process selection.
- Frame-time analysis via Intel PresentMon 2.x (2.6.0 included): FPS, average, 1% and 0.1% lows,
  percentiles, stability score, configurable spike/microstutter/loading detection.
- Event correlation (association vs. baseline, with confidence levels).
- AMD/ATI Disk-Write Inspector (atieclxx.exe, atiesrxx.exe, AMD Software processes), with an
  optional read-only cache-folder size check and a guided, reversible service stop test.
- Existing Workaround Inspector (Game Mode, background recording, Game DVR policy, fullscreen
  optimisations, HAGS, windowed-game optimisations, power plan, SysMain, Windows Search, AMD EEU).
- Smart Fix Engine with ranked recommendations, explicit consent, original-state journal,
  verification and rollback. Elevated operations run through an allow-listed helper.
- Before-and-after benchmarking with noise-aware comparison.
- Djynn Resource Usage panel and session summary.
- Diagnostic report generator: summary.txt, diagnostics.json, performance.csv,
  application-errors.txt, manifest.json (SHA-256 per file) in `DjynnPulse_Diagnostic_<ReportID>.zip`,
  privacy review with category selection and preview, redaction, Copy Summary, Open Folder.
- Send Diagnostic: you save the ZIP, Djynn Pulse opens an email draft to digitaldjynn@outlook.com,
  and you attach the ZIP and send it yourself. Systems without an email app are handled.

## Known limitations

- Frame capture with the bundled PresentMon needs admin rights or the *Performance Log Users*
  group; *Restart as administrator* is offered when needed.
- **CPU temperature needs the PawnIO driver and administrator rights.** Windows has no driver-free
  way to read it. The installer offers PawnIO (ticked by default); the portable package has an
  *Install CPU temperature driver* button. Reading it needs Djynn Pulse running as administrator,
  like frame capture. Without PawnIO, HWiNFO or LibreHardwareMonitor running is used instead.
- GPU sensors through ADL (AMD) work on a Radeon RX 6900 XT. NVML (NVIDIA) is written against
  NVIDIA's documented interface but **has not yet been verified on real hardware**. Intel GPUs get
  sensors only via HWiNFO or LibreHardwareMonitor. Radeon generations before Vega report no ADL
  telemetry.
- The Start menu shortcut and the installer's *Launch* option open Djynn Pulse without
  administrator rights; use *Restart as administrator* for CPU temperature and frame capture.
- VRAM total uses the largest adapter's dedicated memory; on multi-GPU systems the used/total pair
  may refer to different adapters.
- AMD Adrenalin per-game settings are not inspected.
- Memory use measured at 128–159 MB working set, above the 100 MB target (see docs/TESTING.md).
- Executables are not code-signed (SmartScreen warning expected).
- Overhead has so far been measured on one AMD system only, with no game running. See docs/TESTING.md.
