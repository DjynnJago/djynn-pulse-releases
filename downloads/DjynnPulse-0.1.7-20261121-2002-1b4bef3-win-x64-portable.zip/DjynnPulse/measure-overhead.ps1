# Measures Djynn Pulse's own resource use from OUTSIDE the process (independent of its self-report).
# Shipped next to DjynnPulse.exe in the portable package. From the source tree, pass -Exe dist/stage/DjynnPulse/DjynnPulse.exe.
# Put this file in the same folder as DjynnPulse.exe, then run:
#   powershell -ExecutionPolicy Bypass -File .\measure-overhead.ps1
# Optional: -Seconds 120 -Profile UltraLight|Balanced|DeepAnalysis -Advanced -Exe <path to DjynnPulse.exe>
# It starts its own copy of Djynn Pulse, so close Djynn Pulse first. Start your game before running it.
param(
    [string]$Exe = (Join-Path $PSScriptRoot 'DjynnPulse.exe'),
    [int]$Seconds = 120,
    [string]$Profile = 'UltraLight',
    [switch]$Advanced,
    [string]$Screenshot
)
if (-not (Test-Path $Exe)) { throw "DjynnPulse.exe not found at '$Exe'. Put this script next to DjynnPulse.exe or pass -Exe <path>." }
if (Get-Process DjynnPulse -ErrorAction SilentlyContinue) { throw 'Djynn Pulse is already running. Close it first; this script starts its own copy.' }
Write-Host "Measuring for $Seconds s after a 15 s warm-up. Keep playing..."
$argList = @('--start-monitoring', "--profile=$Profile")
if ($Advanced) { $argList += '--page=Performance' }   # -Advanced: measure with the chart-heavy Performance page open
$p = Start-Process -FilePath $Exe -ArgumentList $argList -PassThru
Start-Sleep -Seconds 15   # warm-up (JIT, first PDH collections)
$p.Refresh()
$cpu0 = $p.TotalProcessorTime.TotalMilliseconds; $t0 = Get-Date
$io0 = (Get-CimInstance Win32_Process -Filter "ProcessId=$($p.Id)")
$ws = New-Object System.Collections.Generic.List[double]
for ($i = 0; $i -lt $Seconds; $i++) {
    Start-Sleep -Seconds 1
    $p.Refresh(); if ($p.HasExited) { throw "Djynn Pulse exited during measurement (code $($p.ExitCode))." }
    $ws.Add($p.WorkingSet64 / 1MB)
}
$p.Refresh()
$cpu1 = $p.TotalProcessorTime.TotalMilliseconds; $t1 = Get-Date
$io1 = (Get-CimInstance Win32_Process -Filter "ProcessId=$($p.Id)")
$wall = ($t1 - $t0).TotalMilliseconds
$cpuPct = ($cpu1 - $cpu0) / ($wall * [Environment]::ProcessorCount) * 100
$writeKBs = ($io1.WriteTransferCount - $io0.WriteTransferCount) / 1KB / ($wall / 1000)
$readKBs = ($io1.ReadTransferCount - $io0.ReadTransferCount) / 1KB / ($wall / 1000)

if ($Screenshot) {
    Add-Type -AssemblyName System.Drawing, System.Windows.Forms
    $b = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
    $bmp = New-Object System.Drawing.Bitmap $b.Width, $b.Height
    $g = [System.Drawing.Graphics]::FromImage($bmp); $g.CopyFromScreen($b.Location, [System.Drawing.Point]::Empty, $b.Size)
    $bmp.Save($Screenshot, [System.Drawing.Imaging.ImageFormat]::Png); $g.Dispose(); $bmp.Dispose()
}
$p.CloseMainWindow() | Out-Null
if (-not $p.WaitForExit(5000)) { $p.Kill() }

[pscustomobject]@{
    Profile = $Profile; AdvancedUI = [bool]$Advanced; Seconds = [math]::Round($wall / 1000)
    LogicalProcessors = [Environment]::ProcessorCount
    CpuPercentOfMachine = [math]::Round($cpuPct, 3)
    WorkingSetAvgMB = [math]::Round(($ws | Measure-Object -Average).Average, 1)
    WorkingSetMaxMB = [math]::Round(($ws | Measure-Object -Maximum).Maximum, 1)
    LogicalWriteKBps = [math]::Round($writeKBs, 2)
    LogicalReadKBps = [math]::Round($readKBs, 2)
}
